//
//  DetailViewController.swift
//  WeatherMap
//
//  Created by MacBook Pro on 28.05.26.
//

//import UIKit

//class DetailViewController : UIViewController {
    
    //override func viewDidLoad() {
      //  super.viewDidLoad()
    //    view.backgroundColor = .systemMint
            
  //  }
//}
//
//  DetailViewController.swift
//  WeatherMap
//
//  Created by MacBook Pro on 28.05.26.
//

import UIKit
import CoreLocation

class DetailViewController: UIViewController {
    
    var coordinate: CLLocationCoordinate2D?
    var locationName: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemMint
        title = locationName
        
        // აქ მოგვიწევს ამინდის API-დან მონაცემების fetch-ი
        // coordinate property-ით
    }
}
