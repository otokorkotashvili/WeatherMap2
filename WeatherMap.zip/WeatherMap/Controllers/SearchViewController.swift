
//
//  SearchViewController.swift
//  WeatherMap
//
//  Created by MacBook Pro on 28.05.26.
//

import UIKit
import MapKit

class SearchViewController: UITableViewController {
    
    let searchController = UISearchController()
    var matchingLocations: [MKMapItem] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        navigationController?.navigationBar.prefersLargeTitles = true
        title = "Search"
        self.tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        addSearchController()
    }
    
    func addSearchController() {
        searchController.searchBar.sizeToFit()
        searchController.searchBar.backgroundImage = UIImage()
        searchController.searchBar.tintColor = .systemPurple
        searchController.searchBar.searchTextField.leftView?.tintColor = .systemPurple
        searchController.searchResultsUpdater = self
        searchController.obscuresBackgroundDuringPresentation = false
        searchController.searchBar.placeholder = "Search"
        searchController.searchBar.delegate = self
        navigationItem.searchController = searchController
    }
    
    // MARK: - Helper
    func formatAddress(from placemark: MKPlacemark) -> String? {
        let parts = [
            placemark.thoroughfare,
            placemark.locality,
            placemark.administrativeArea,
            placemark.country
        ].compactMap { $0 }
        
        return parts.isEmpty ? nil : parts.joined(separator: ", ")
    }
}

// MARK: - UISearchResultsUpdating
extension SearchViewController: UISearchResultsUpdating {
    func updateSearchResults(for searchController: UISearchController) {
        performSearch()
    }
    
    func performSearch() {
        guard let searchBarText = searchController.searchBar.text else { return }
        let trimmed = searchBarText.trimmingCharacters(in: .whitespacesAndNewlines)
        
        if trimmed.isEmpty {
            self.matchingLocations = []
            self.tableView.reloadData()
            return
        }
        
        let request = MKLocalSearch.Request()
        request.naturalLanguageQuery = trimmed
        let search = MKLocalSearch(request: request)
        search.start { response, error in
            if let error = error {
                print("Search Failed", error)
                return
            }
            guard let response = response else { return }
            DispatchQueue.main.async {
                self.matchingLocations = response.mapItems
                self.tableView.reloadData()
            }
        }
    }
}

// MARK: - UISearchBarDelegate
extension SearchViewController: UISearchBarDelegate {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText.isEmpty {
            matchingLocations = []
            self.tableView.reloadData()
        }
    }
}

// MARK: - UITableViewDataSource
extension SearchViewController {
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return matchingLocations.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let mapItem = matchingLocations[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        var configuration = cell.defaultContentConfiguration()
        configuration.imageToTextPadding = 20
        
        configuration.attributedText = NSAttributedString(
            string: mapItem.name ?? "",
            attributes: [.font: UIFont.systemFont(ofSize: 20, weight: .bold)]
        )
        
        if let address = formatAddress(from: mapItem.placemark), !address.isEmpty {
            configuration.secondaryText = address
        } else if let coordinate = mapItem.placemark.location?.coordinate {
            configuration.secondaryText = String(format: "%.5f, %.5f", coordinate.latitude, coordinate.longitude)
        } else {
            configuration.secondaryText = nil
        }
        
        configuration.image = UIImage(systemName: "location.fill.viewfinder")
        configuration.imageProperties.tintColor = .systemPurple
        cell.contentConfiguration = configuration
        cell.accessoryType = .disclosureIndicator
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        let mapItem = matchingLocations[indexPath.row]
        let detailVC = DetailViewController()
        detailVC.coordinate = mapItem.placemark.coordinate
        detailVC.locationName = mapItem.name
        
        searchController.isActive = false
        navigationController?.pushViewController(detailVC, animated: true)
    }
}

