//
//  weather.swift
//  WeatherMap
//
//  Created by MacBook Pro on 18.06.26.
//

//
//  WeatherModel.swift
//  WeatherMap
//
//  Created by MacBook Pro on 18.06.26.
//

import Foundation

struct CurrentWeatherResponse: Codable {
    let name: String
    let main: MainWeather
    let weather: [WeatherCondition]
    let wind: Wind
}

struct ForecastResponse: Codable {
    let list: [ForecastItem]
}

struct ForecastItem: Codable {
    let main: MainWeather
    let weather: [WeatherCondition]
    let dtTxt: String
    
    enum CodingKeys: String, CodingKey {
        case main, weather
        case dtTxt = "dt_txt"
    }
}

struct MainWeather: Codable {
    let temp: Double
    let humidity: Int
}

struct WeatherCondition: Codable {
    let main: String
    let description: String
    let icon: String
}

struct Wind: Codable {
    let speed: Double
}
