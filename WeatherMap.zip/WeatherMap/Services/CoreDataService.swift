//
//  CoreDataService.swift
//  WeatherMap
//
//  Created by MacBook Pro on 28.05.26.
//

import CoreData
import UIKit

struct CoreDataService {
    
    static let persistenceContainer: NSPersistentContainer = {
        let container = NSPersistentContainer(name: "FavouritesModel")
        container.loadPersistentStores { (description, error) in
            if let error = error {
                fatalError("Unable to load persistent stores: \(error)")
            }
        }
        return container
    }()
    
    static var context: NSManagedObjectContext {
        return persistenceContainer.viewContext
    }
    
    func addLocation(name: String, country: String, longitude: Double, latitude: Double) {
        
        let context = CoreDataService.context
        let location = NSEntityDescription.insertNewObject(forEntityName: "Favourites", into: context)
        
        location.setValue(name, forKey: "name")
        location.setValue(longitude, forKey: "longitude")
        location.setValue(latitude, forKey: "latitude")
        location.setValue(country, forKey: "country")
        
        do {
            try context.save()
        } catch let error {
            print("Failed to save location. \(error)")
        }
    }
    
    func fetchLocations() -> [Favourites] {
        let context = CoreDataService.context
        let fetchRequest = NSFetchRequest<Favourites>(entityName: "Favourites")  // ✅ გასწორებულ
        let sortDescriptor = NSSortDescriptor(key: "name", ascending: true)
        fetchRequest.sortDescriptors = [sortDescriptor]
        
        
        do {
               let locations = try CoreDataService.context.fetch(fetchRequest)
               return locations
           } catch let error {
               print("Failed to fetch locations from Core Data \(error.localizedDescription)")
               return []
           }
    }
    
    func deleteLocation(_ location: NSManagedObject) {
        let context = CoreDataService.context
        context.delete(location)
        
        do {
            try context.save()
        } catch let error {
            print("Failed to delete location. \(error)")
        }
    }
}
