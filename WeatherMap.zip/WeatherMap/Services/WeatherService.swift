//
//  WeatherService.swift
//  WeatherMap
//
//  Created by MacBook Pro on 18.06.26.
//

import Foundation

struct WeatherService {
    
    private let apiKey = "42ca1ba88044a1d5acb2523bb6a89d65"
    
    func fetchCurrentWeather(latitude: Double, longitude: Double) async throws -> CurrentWeatherResponse {
        let urlString = "https://api.openweathermap.org/data/2.5/weather?lat=\(latitude)&lon=\(longitude)&appid=\(apiKey)&units=metric"
        guard let url = URL(string: urlString) else { throw URLError(.badURL) }
        
        let (data, _) = try await URLSession.shared.data(from: url)
        return try JSONDecoder().decode(CurrentWeatherResponse.self, from: data)
    }
    
    func fetchForecast(latitude: Double, longitude: Double) async throws -> [ForecastItem] {
        let urlString = "https://api.openweathermap.org/data/2.5/forecast?lat=\(latitude)&lon=\(longitude)&appid=\(apiKey)&units=metric"
        guard let url = URL(string: urlString) else { throw URLError(.badURL) }
        
        let (data, _) = try await URLSession.shared.data(from: url)
        let decoded = try JSONDecoder().decode(ForecastResponse.self, from: data)
        
        // ვფილტრავთ მხოლოდ შუადღის (12:00) ჩანაწერებს — 5 დღე
        return decoded.list.filter { $0.dtTxt.contains("12:00:00") }
    }
}
